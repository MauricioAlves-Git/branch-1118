moodle-webservice_restjson
================================

REST webservice protocol based on the standard core REST webservice, but with added support for JSON & XML payloads
and supports using HTTP ACCEPTS headers for determining response format.

Installation
------------

Simply place the filter files in ./webservice/restjson

Setup
-----

Should be enabled and setup in the standard way for webservices.  See https://docs.moodle.org/29/en/Using_web_services
for details.